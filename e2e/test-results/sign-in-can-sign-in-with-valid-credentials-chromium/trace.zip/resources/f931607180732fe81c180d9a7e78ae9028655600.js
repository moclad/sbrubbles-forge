(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/apps_app_app_[locale]_not-found_tsx_3b97070d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/apps_app_app_[locale]_not-found_tsx_3b97070d._.js",
  "chunks": [
    "static/chunks/_6712b34d._.js"
  ],
  "source": "dynamic"
});
