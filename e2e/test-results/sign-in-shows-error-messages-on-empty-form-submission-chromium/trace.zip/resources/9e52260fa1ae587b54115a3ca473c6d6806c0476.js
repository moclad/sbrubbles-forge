(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/7563d_next_dist_client_components_not-found-error_58d22447.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/7563d_next_dist_client_components_not-found-error_58d22447.js",
  "chunks": [
    "static/chunks/7563d_next_dist_ef76c9a5._.js"
  ],
  "source": "dynamic"
});
