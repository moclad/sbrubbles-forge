(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/packages_localization_locales_en_ts_16b0fef2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/packages_localization_locales_en_ts_16b0fef2._.js",
  "chunks": [
    "static/chunks/packages_localization_locales_en_ts_1c8e6c56._.js"
  ],
  "source": "dynamic"
});
