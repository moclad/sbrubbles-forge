(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/packages_localization_locales_97f05e68._.js", {

"[project]/packages/localization/locales/en.ts [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_localization_locales_en_ts_1c8e6c56._.js",
  "static/chunks/packages_localization_locales_en_ts_16b0fef2._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/localization/locales/en.ts [app-client] (ecmascript)");
    });
});
}}),
"[project]/packages/localization/locales/de.ts [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_localization_locales_de_ts_617a16d3._.js",
  "static/chunks/packages_localization_locales_de_ts_16b0fef2._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/localization/locales/de.ts [app-client] (ecmascript)");
    });
});
}}),
"[project]/packages/localization/locales/pt-BR.ts [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_localization_locales_pt-BR_ts_235749f5._.js",
  "static/chunks/packages_localization_locales_pt-BR_ts_16b0fef2._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/localization/locales/pt-BR.ts [app-client] (ecmascript)");
    });
});
}}),
}]);