(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/apps_app_app_[locale]_(unauthenticated)_layout_tsx_3b97070d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/apps_app_app_[locale]_(unauthenticated)_layout_tsx_3b97070d._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_ac07fcfa._.js",
    "static/chunks/node_modules__pnpm_2ac2c417._.js",
    "static/chunks/packages_design-system_components_14473989._.js"
  ],
  "source": "dynamic"
});
