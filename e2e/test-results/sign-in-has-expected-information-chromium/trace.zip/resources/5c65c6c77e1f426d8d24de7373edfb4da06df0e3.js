(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/apps_app_app_[locale]_layout_tsx_58d22447._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/apps_app_app_[locale]_layout_tsx_58d22447._.js",
  "chunks": [
    "static/chunks/_0d443dba._.css",
    "static/chunks/packages_localization_locales_97f05e68._.js",
    "static/chunks/05b4d_zod_lib_index_mjs_b32e4c10._.js",
    "static/chunks/9c939_tailwind-merge_dist_bundle-mjs_mjs_5274cb0a._.js",
    "static/chunks/53830_@sentry_core_build_esm_eab6814b._.js",
    "static/chunks/node_modules__pnpm_c764c407._.js",
    "static/chunks/packages_c936251c._.js"
  ],
  "source": "dynamic"
});
