(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/apps_app_app_[locale]_(unauthenticated)_sign-in_[[___sign-in]]_page_tsx_2391f8fd._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/apps_app_app_[locale]_(unauthenticated)_sign-in_[[___sign-in]]_page_tsx_2391f8fd._.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_18204746._.js",
    "static/chunks/packages_a1288942._.js"
  ],
  "source": "dynamic"
});
