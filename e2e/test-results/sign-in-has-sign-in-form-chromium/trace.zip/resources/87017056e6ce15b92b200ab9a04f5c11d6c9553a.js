(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/apps_app_e69f0d32._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/apps_app_e69f0d32._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_81214bdf._.js",
    "static/chunks/7563d_next_dist_compiled_0c3ca1a1._.js",
    "static/chunks/7563d_next_dist_client_e689f411._.js",
    "static/chunks/7563d_next_dist_556b273c._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js"
  ],
  "source": "entry"
});
